export const Tabs = ({ children }) => <div>{children}</div>;
export const TabsList = ({ children }) => <div className='flex gap-2'>{children}</div>;
export const TabsTrigger = ({ children, value }) => <button>{children}</button>;
export const TabsContent = ({ children, value }) => <div>{children}</div>;